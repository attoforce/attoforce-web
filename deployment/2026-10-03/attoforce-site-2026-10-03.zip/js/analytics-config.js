// Site-specific Plausible script supplied by DP on 9 September 2026.
// This file contains only public configuration; never add passwords or API keys.
window.ATTOFORCE_ANALYTICS = Object.freeze({
  enabled: true,
  provider: 'plausible',
  scriptUrl: 'https://plausible.io/js/pa-9LQf_RswYCXxslWU9dcX4.js',
  allowedHosts: ['attoforce.ai', 'www.attoforce.ai'],
  options: {
    captureOnLocalhost: false,
    outboundLinks: false,
    fileDownloads: false,
    formSubmissions: false,
    transformRequest(payload) {
      // Keep enquiry text, email subjects and campaign query strings out of analytics.
      if (payload.u) { const url = new URL(payload.u); payload.u = url.origin + url.pathname; }
      if (payload.r) { try { payload.r = new URL(payload.r).origin; } catch { payload.r = ''; } }
      if (payload.p) delete payload.p.url;
      return payload;
    },
  },
});
