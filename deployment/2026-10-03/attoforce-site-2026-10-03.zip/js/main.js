const year = document.getElementById('year');
if (year) year.textContent = new Date().getFullYear();
const menu = document.querySelector('.mobile-menu');
menu?.addEventListener('click', event => { if (event.target.closest('a')) menu.open = false; });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && menu?.open) { menu.open = false; menu.querySelector('summary').focus(); }
});
document.addEventListener('click', event => {
  if (menu?.open && !menu.contains(event.target)) menu.open = false;
});
const media = window.matchMedia('(prefers-reduced-motion: reduce)');
if (!media.matches && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) if (entry.isIntersecting) {
      entry.target.classList.add('animate-in');
      observer.unobserve(entry.target);
    }
  }, {threshold: 0.1});
  document.querySelectorAll('.section-intro, .method-heading, .about-grid').forEach(element => observer.observe(element));
}

document.querySelectorAll('.motion-toggle').forEach(motionButton => {
  motionButton.addEventListener('click', () => {
    const paused = motionButton.getAttribute('aria-pressed') !== 'true';
    motionButton.setAttribute('aria-pressed', String(paused));
    motionButton.setAttribute('aria-label', paused ? 'Resume diagram animation' : 'Pause diagram animation');
    motionButton.innerHTML = paused ? 'Resume motion <span aria-hidden="true">▶</span>' : 'Pause motion <span aria-hidden="true">Ⅱ</span>';
    motionButton.closest('.delivery-flow')?.classList.toggle('motion-paused', paused);
  });
});

// Keep native mailto links usable without JavaScript and offer a clipboard fallback.
document.querySelectorAll('[data-copy-email]').forEach(copyButton => {
  copyButton.hidden = false;
  copyButton.addEventListener('click', async () => {
    const email = copyButton.dataset.copyEmail;
    const status = copyButton.closest('.career-apply').querySelector('.career-copy-status');
    status.textContent = '';
    try {
      await navigator.clipboard.writeText(email);
      status.textContent = 'Email address copied. Paste it into a new message and include the role title in the subject.';
    } catch {
      status.textContent = `Copy this address manually: ${email}`;
    }
  });
});
