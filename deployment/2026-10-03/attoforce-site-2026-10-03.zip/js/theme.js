// Runs before the stylesheet so the saved preference applies before first paint.
(() => {
  const key = 'attoforce-theme';
  const allowed = new Set(['auto', 'day', 'night']);
  const system = window.matchMedia('(prefers-color-scheme: dark)');
  let preference = 'auto';
  let buttons = [];
  try {
    const saved = localStorage.getItem(key);
    if (allowed.has(saved)) preference = saved;
  } catch { /* The switch still works when browser storage is unavailable. */ }
  function apply() {
    const dark = preference === 'night' || (preference === 'auto' && system.matches);
    document.documentElement.dataset.theme = dark ? 'night' : 'day';
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#141414' : '#ffffff');
    buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.themeChoice === preference)));
  }
  apply();
  system.addEventListener('change', () => { if (preference === 'auto') apply(); });
  window.addEventListener('storage', event => {
    if (event.key !== key && event.key !== null) return;
    preference = allowed.has(event.newValue) ? event.newValue : 'auto';
    apply();
  });
  document.addEventListener('DOMContentLoaded', () => {
    const picker = document.querySelector('.theme-picker');
    if (!picker) return;
    buttons = [...picker.querySelectorAll('[data-theme-choice]')];
    buttons.forEach(button => button.addEventListener('click', () => {
      preference = allowed.has(button.dataset.themeChoice) ? button.dataset.themeChoice : 'auto';
      try {
        if (preference === 'auto') localStorage.removeItem(key);
        else localStorage.setItem(key, preference);
      } catch { /* Keep the preference for this page even if it cannot be saved. */ }
      apply();
    }));
    apply();
    picker.hidden = false;
  });
})();
