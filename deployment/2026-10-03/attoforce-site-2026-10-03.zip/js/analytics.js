(() => {
  const config = window.ATTOFORCE_ANALYTICS || {};
  const local = !config.allowedHosts?.includes(location.hostname);
  const disclosure = document.getElementById('analytics-disclosure');
  if (disclosure) disclosure.textContent = local ? 'Analytics is inactive in this preview. It does not load Plausible or send visitor events.' : 'Plausible is currently inactive on this page. The description below explains the configured measurement.';
  const events = new Set(['Explore offerings', 'Offering click', 'Contact intent', 'Email click', 'LinkedIn click']);
  const offerings = new Set(['agentic-ai', 'ai-driven-development', 'ai-governance', 'data-analytics', 'aws-modernization']);
  // Production HTML contains the supplied snippet once. Preview HTML omits it.
  const active = config.enabled && !local && config.provider === 'plausible' && window.ATTOFORCE_ANALYTICS_STARTED;
  const failed = () => {
    window.ATTOFORCE_PLAUSIBLE_FAILED = true;
    if (disclosure) disclosure.textContent = 'Plausible could not load on this page. The description below explains the configured measurement.';
  };
  if (active) {
    if (disclosure) disclosure.textContent = 'Plausible is configured on this public website to measure aggregate traffic and selected link clicks. The details below explain the information involved.';
    if (window.ATTOFORCE_PLAUSIBLE_FAILED) failed();
    document.getElementById('plausible-script')?.addEventListener('error', failed);
  }
  document.addEventListener('click', event => {
    const element = event.target.closest('[data-event]');
    if (!element || !events.has(element.dataset.event)) return;
    const props = {page: location.pathname};
    if (offerings.has(element.dataset.offering)) props.offering = element.dataset.offering;
    const eventName = props.offering ? `${element.dataset.event}: ${props.offering}` : element.dataset.event;
    if (active && !window.ATTOFORCE_PLAUSIBLE_FAILED && typeof window.plausible === 'function') window.plausible(eventName);
    // Local verification hook only; no network request or browser storage.
    if (local) document.dispatchEvent(new CustomEvent('attoforce:analytics', {detail:{name:eventName,props}}));
  });
})();
